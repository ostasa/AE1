package AE3;
//clase minero con una variable bolsa , tiempo extraccion, mina y nombre
public class Minero implements Runnable{
int bolsa;
int tiempoExtraccion=100;
Mina mina;
String nombre;
//setter de bolsa
public void setBolsa(int bolsa) {
	this.bolsa = bolsa;
}
//getter de bolsa
public int getBolsa() {
	return bolsa;
}
// constructor en el que se a�ade el valor de mina y nombre 
public Minero(Mina mina, String nom) {
	bolsa=0;
	this.mina=mina;
	nombre=nom;
}
//extraerRecurso Es un metodo que resta 1 al stock y lo suma a bolsa 
//tambien descansa el hilo el tiempo de extraccion
public void extraerRecurso(){
	synchronized (this) {
	
	while(mina.stock>=1) {
		try {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}if(mina.getStock()>=1) {
		mina.stock-=1;
		bolsa+=1;
		System.out.println(nombre+" Ha sacado un oro y tiene en su bolsa "+ bolsa);}
		
		}
		try {
			Thread.sleep(tiempoExtraccion);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}}}
public void run() {
	extraerRecurso();
}
	
}

