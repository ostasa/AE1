package AE3;

import java.util.ArrayList;
import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		//se le a�ade valor a stock y se crea el objeto mina
		int stock;
		System.out.println("Que stock quieres en la mina?");
		stock=Integer.parseInt(x.nextLine());	
		Mina mina = new Mina(stock);

		
		/*Minero minero1 = new Minero();
		Minero minero2 = new Minero();
		Minero minero3 = new Minero();
		Minero minero4 = new Minero();
		Minero minero5 = new Minero();
		Minero minero6 = new Minero();
		Minero minero7 = new Minero();
		Minero minero8 = new Minero();
		Minero minero9 = new Minero();
		Minero minero10 = new Minero();*/
		//Se crea el hilo, tambien el array list de objeto mineros y se hace un for en el que se a�ade mineros al arrayList
		Thread t;
		int total=0;
		ArrayList<Minero> mineros=new ArrayList<Minero>();

		//se crea un for para a�adir un minero a un hilo y comenzar el start
		for (int i = 0; i < 10; i++) {
		String nombre = "minero"+(i+1);
		Minero minero = new Minero(mina, nombre);
		mineros.add(minero);
		t = new Thread(mineros.get(i));
		t.setName("minero" + (i + 1));
		t.start();
		
		}
		// descansa el hilo y suma las bolsas de los mienros para obtener el  total
		try {
		Thread.sleep(1000);
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
		for(int i =0; i<mineros.size();i++) {
		total += mineros.get(i).getBolsa();}
		System.out.println("Total de oro reacaudado "+total);
		System.out.println("Oro que queda en la mina "+mina.stock)

		
		/*Thread  hilo1 = new Thread(minero1.extraerRecurso(mina));
		Thread  hilo2 = new Thread(minero2.extraerRecurso(mina));
		Thread  hilo3 = new Thread(minero3.extraerRecurso(mina));
		Thread  hilo4 = new Thread(minero4.extraerRecurso(mina));
		Thread  hilo5 = new Thread(minero5.extraerRecurso(mina));
		Thread  hilo6 = new Thread(minero6.extraerRecurso(mina));
		Thread  hilo7 = new Thread(minero7.extraerRecurso(mina));
		Thread  hilo8 = new Thread(minero8.extraerRecurso(mina));
		Thread  hilo9 = new Thread(minero9.extraerRecurso(mina));
		Thread  hilo10 = new Thread(minero10.extraerRecurso(mina));*/
		/*System.out.println(minero1.getBolsa() + minero2.getBolsa()+ minero3.getBolsa()+ minero4.getBolsa()+ minero5.getBolsa()+ minero6.getBolsa()
		+ minero7.getBolsa()+ minero8.getBolsa()+ minero9.getBolsa()+ minero10.getBolsa())*/;
		
		
	}
		

}
