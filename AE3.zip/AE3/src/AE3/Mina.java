package AE3;
//clase Mina con una variable stock que tiene el numero de oro
public class Mina {
 int stock;
 //Constructor en el que se a�ade el valor a stock
 public Mina(int st){stock=st;}
 //getter de stock
public int getStock() {
	return stock;
}
//setter de stock
public void setStock(int stock) {
	this.stock = stock;
}
 
}
