package AE2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;

public class Neo {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ens guardem la data en la que comen�em la funcio
		long startTime = System.currentTimeMillis();
		//agafem la informacio del arxiu desde el lanzador amb els arguments que l'hem passat
		String nombre = args[0];
		Double posicionNEO = Double.parseDouble(args[1]);
		Double velocidadNEO=Double.parseDouble(args[2]);
		//la terra sempre comen� en el mateix lloc
		double posicionTierra = 1;
		double velocidadTierra = 100;
		//calcula la probabilidad del choque
		for (int i = 0; i < (50 * 365 * 24 * 60 * 60); i++) {
		posicionNEO = posicionNEO + velocidadNEO * i;
		posicionTierra = posicionTierra + velocidadTierra * i;
		}
		double resultado = 100 * Math.random() *
		Math.pow( ((posicionNEO-posicionTierra)/(posicionNEO+posicionTierra)), 2);
		File fichero = new File (nombre+".txt");
		
		try {
			//Se comprueba si el fichero se ha creado 
			  if (fichero.createNewFile())
			    System.out.println("El fichero se ha creado correctamente");
			  FileWriter fic=null;
		try {
			fic = new FileWriter(fichero);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Se le da al resultado el formato que se ha requerido
		String patron = "##.##";
		DecimalFormat f = new DecimalFormat(patron);
		String resul = f.format(resultado);
		BufferedWriter pw= new BufferedWriter(fic);
		try {
			pw.write(resul+"%");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Se resta que teimpo es ahora con el del comienzo y se divide entre mil para ponerlo en segundos
		double total= ((System.currentTimeMillis()-startTime)/1000);
 if(resultado>10) {
	 System.err.println(resul+
			 " % "+"Mas de 10 Por ciento"+" Este neo ha tardado "+ total + " Segundos");
 }else {System.out.println(resul+" % " +"La probabilidad es baja"+" Este neo ha tardado "+ total + " Segundos");}
			} catch (IOException ioe) {
			  ioe.printStackTrace();
			}
		
	}

}
