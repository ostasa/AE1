package AE2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Lanzador {
// Aquesta clase comen�a i pasa els arguments al neo
	public void lanzaSumador(String nombre, int posicion,int velocidad){
		String clase = "AE2.Neo";
		try {
// se ponen les clases
		String javaHome = System.getProperty("java.home");
		String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
		String classpath = System.getProperty("java.class.path");
		String className = clase;
// se guarda en un array que seran los argumenro de neo java
		List<String> command = new ArrayList<>();
		command.add(javaBin);
		command.add("-cp");
		command.add(classpath);
		command.add(className);
		command.add(nombre);
		command.add(String.valueOf(posicion));
		command.add(String.valueOf(velocidad));
		
		//Aqui se envia el array a neo.java
		ProcessBuilder builder = new ProcessBuilder(command);
		Process process = builder.inheritIO().start();
		process.waitFor();

		} catch (Exception e) {
		e.printStackTrace();
		}
	}
	//Aquest main es el que hi ha que llan�ar per a iniciar l'aplicaci�
	public static void main(String[] args) {String[] linea;
	//Se crea el lazador
	Lanzador lanz = new Lanzador();
	//Se varigua los cores
	int core = Runtime.getRuntime().availableProcessors();
	//Aquesta es la ruta del arxiu. Como esta en el lloc de la pp solo fa falta el nom del archiu i la seua extensi� 
	String ruta= "NEOs.txt";
	
	try {
		//se guarda el temps en el que comen�em
		long startTim = System.currentTimeMillis();
		//se crea un File con la ruta del arxiu
		File f = new File(ruta);
		// Creem un Filereader i un BufferedReader per a poder llegirlo
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		//es llig
		String lin = br.readLine();
		//Se crea un bucle amb el nombre de cores per a llegir les linees que corresponguen sense sobrecargar el procesador
		for (int i = 0; i < core; i++) {
			//se fa creure q una linea es hasta la coma
			linea= lin.split(",");
			System.out.println(linea + "\n");
			//Fem el lanza sumador amb la linea q toca
			lanz.lanzaSumador(linea[0] , Integer.valueOf(linea[1]), Integer.valueOf(linea[2]));
		}
		
		br.close();
		fr.close();
		//restem el temps que estem amb el que em comen�at y el dividim per 100 per a que siga segonds
		double tot= ((System.currentTimeMillis()-startTim)/1000);
		System.out.println("Neo ha tardado en ejecutarse "+tot+" segundos");
		
	} catch (Exception e) {
	}

}

}


